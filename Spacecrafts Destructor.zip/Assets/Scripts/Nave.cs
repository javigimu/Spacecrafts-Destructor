using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Nave : MonoBehaviour
{
    private float bordeIzquierdo;
    private float bordeDerecho;
    private float bordeSuperior;
    private float bordeInferior;
    [SerializeField] float velocidad;
    [SerializeField] Transform prefabDisparo;
    private float velocidadDisparo;
    private float tiempoEsperaDisparo;
    private bool disparado;

    [SerializeField] Transform prefabExplosion;

    // Start is called before the first frame update
    void Start()
    {
        bordeIzquierdo = -4.6f;
        bordeDerecho = 4.6f;
        bordeSuperior = 3.4f;
        bordeInferior = -3.4f;
        velocidadDisparo = 5f;
        tiempoEsperaDisparo = 0.4f;
        disparado = false;
    }

    // Update is called once per frame
    void Update()
    {
        MoverNave();

        if (Input.GetButtonDown("Fire1") && !disparado)
        {
            StartCoroutine(DispararConRetardo());
            disparado = true;
        }

        if (Input.GetKey(KeyCode.Escape))
            SceneManager.LoadScene("Bienvenida");
    }

    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.tag == "Enemigo")
        {
            otro.SendMessage("Destruir");
            Destruir();
        }
    }

    private IEnumerator DispararConRetardo()
    {        
        Disparar();
        yield return new WaitForSeconds(tiempoEsperaDisparo);
        disparado = false;
    }

    private void Disparar()
    {
        ReproducirSonidoDisparo();

        Transform disparo = Instantiate(prefabDisparo, transform.position,
            Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
            new Vector3(velocidadDisparo, 0, 0);
    }

    private void MoverNave()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        if (transform.position.x < bordeIzquierdo ||
            transform.position.x > bordeDerecho ||
            transform.position.y > bordeSuperior ||
            transform.position.y < bordeInferior)
        {
            SepararDelBorde();
        }
        else
        {
            transform.Translate(horizontal * velocidad * Time.deltaTime,
                vertical * velocidad * Time.deltaTime, 0);
        }
    }
    private void SepararDelBorde()
    {
        if (transform.position.x < bordeIzquierdo)
            transform.position = new Vector3(bordeIzquierdo,
                transform.position.y, 0);
        else if (transform.position.x > bordeDerecho)
            transform.position = new Vector3(bordeDerecho,
                transform.position.y, 0);
        else if (transform.position.y > bordeSuperior)
            transform.position = new Vector3(transform.position.x,
                bordeSuperior, 0);
        else if (transform.position.y < bordeInferior)
            transform.position = new Vector3(transform.position.x,
                bordeInferior, 0);
    }

    private void Destruir()
    {
        Transform explosion = Instantiate(prefabExplosion, transform.position,
            Quaternion.identity);
        Destroy(gameObject);
        Destroy(explosion.gameObject, 1f);
    }

    private void ReproducirSonidoDisparo()
    {
        GetComponent<AudioSource>().Play();
    }
}
