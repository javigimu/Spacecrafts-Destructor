using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemigo : MonoBehaviour
{
    private float bordeSuperior;
    private float bordeInferior;
    private float velocidadY = 3f;
    private float avanceX;    

    [SerializeField] Transform prefabExplosion;
    [SerializeField] Transform prefabDisparoEnemigo;
    private float velocidadDisparo;

    // Start is called before the first frame update
    void Start()
    {
        bordeSuperior = 3.4f;
        bordeInferior = -3.4f;
        avanceX = -0.2f;
        velocidadDisparo = -5f;
        StartCoroutine(Disparar());
    }

    // Update is called once per frame
    void Update()
    {
        MoverEnemigo();       
    }
    private void MoverEnemigo()
    {
        if (transform.position.y > bordeSuperior ||
            transform.position.y < bordeInferior)
        {
            Avanzar();
        }
        transform.Translate(0, velocidadY * Time.deltaTime, 0);
    }
    private void Avanzar()
    {
        velocidadY = -velocidadY;
        if (transform.position.y > bordeSuperior)
        {
            transform.position = new Vector3(transform.position.x + avanceX,
                bordeSuperior, 0);
        }
        else if (transform.position.y < bordeInferior)
        {
            transform.position = new Vector3(transform.position.x + avanceX,
                bordeInferior, 0);
        }
    }

    // Funci�n para destruir el objeto enemigo mostrando una explosi�n
    private void Destruir()
    {
        Transform explosion = Instantiate(prefabExplosion, transform.position,
            Quaternion.identity);
        Destroy(gameObject);
        Destroy(explosion.gameObject, 1f);
    }

    private IEnumerator Disparar()
    {
        float pausaDisparo = Random.Range(0.5f, 4f);
        yield return new WaitForSeconds(pausaDisparo);

        ReproducirSonidoDisparo();

        Transform disparo = Instantiate(prefabDisparoEnemigo,
            transform.position, Quaternion.identity);
        disparo.gameObject.GetComponent<Rigidbody2D>().velocity =
            new Vector3(velocidadDisparo, 0, 0);
        StartCoroutine(Disparar());
    }

    private void ReproducirSonidoDisparo()
    {
        GetComponent<AudioSource>().Play();
    }
}
