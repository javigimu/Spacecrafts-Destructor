using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisparoNave : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        ReproducirSonidoDisparo();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D otro)
    {
        if (otro.tag == "BordeDerecho")
            Destroy(gameObject);
        else if (otro.tag == "Enemigo")
        {
            otro.SendMessage("Destruir");
            Destroy(gameObject);
        }
    }

    private void  ReproducirSonidoDisparo()
    {
        GetComponent<AudioSource>().Play();
    }
}
